<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$email_usuario = $usuario['email'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar formulário de atualização
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha_atual = $_POST['senha_atual'];
    $nova_senha = $_POST['nova_senha'];
    
    // Verificar se a senha atual está correta
    if (!empty($senha_atual)) {
        if ($senha_atual === $usuario['senha']) {
            // Atualizar informações básicas
            $sql = "UPDATE usuarios SET nome = :nome, email = :email";
            $params = [':nome' => $nome, ':email' => $email];
            
            // Atualizar senha se fornecida
            if (!empty($nova_senha)) {
                $sql .= ", senha = :senha";
                $params[':senha'] = $nova_senha;
            }
            
            // Processar upload de avatar
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $avatar_nome = $_FILES['avatar']['name'];
                $avatar_tmp = $_FILES['avatar']['tmp_name'];
                $avatar_ext = strtolower(pathinfo($avatar_nome, PATHINFO_EXTENSION));
                
                // Verificar extensão
                $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($avatar_ext, $extensoes_permitidas)) {
                    // Criar diretório de avatares se não existir
                    $diretorio_avatar = 'uploads/avatares/';
                    if (!is_dir($diretorio_avatar)) {
                        mkdir($diretorio_avatar, 0755, true);
                    }
                    
                    // Gerar nome único para o arquivo
                    $novo_nome = uniqid('avatar_') . '.' . $avatar_ext;
                    $caminho_avatar = $diretorio_avatar . $novo_nome;
                    
                    // Mover o arquivo
                    if (move_uploaded_file($avatar_tmp, $caminho_avatar)) {
                        $sql .= ", avatar = :avatar";
                        $params[':avatar'] = $caminho_avatar;
                    }
                }
            }
            
            $sql .= " WHERE id = :id";
            $params[':id'] = $_SESSION['usuario_id'];
            
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute($params)) {
                $mensagem = "Perfil atualizado com sucesso!";
                $tipo_mensagem = "success";
                
                // Atualizar nome na sessão
                $_SESSION['usuario_nome'] = $nome;
                
                // Recarregar informações do usuário
                $query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
                $usuario = $query->fetch(PDO::FETCH_ASSOC);
                $nome_usuario = $usuario['nome'];
                $email_usuario = $usuario['email'];
                $nivel_usuario = $usuario['nivel'];
                $avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';
            } else {
                $mensagem = "Erro ao atualizar perfil.";
                $tipo_mensagem = "error";
            }
        } else {
            $mensagem = "Senha atual incorreta.";
            $tipo_mensagem = "error";
        }
    } else {
        $mensagem = "Digite sua senha atual para confirmar as alterações.";
        $tipo_mensagem = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Editar Perfil - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <style>
        /* Estilos adicionais específicos para esta página */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #121212;
            color: #fff;
        }
        
        .navbar-bg {
            background-color: #1a1a1a;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        
        .main-sidebar {
            background-color: #1a1a1a;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.5);
        }
        
        .profile-container {
            background-color: #2a2a2a;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .profile-title {
            color: #00aaff;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #444;
        }
        
        .avatar-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .avatar-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 15px;
            border: 3px solid #00aaff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        
        .avatar-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
            color: #ccc;
        }

        .form-group label[for='senha_atual'] {
            color: #e0e0e0; /* Cinza mais claro */
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 8px;
            background-color: #333;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #00aaff;
            box-shadow: 0 0 5px rgba(0, 170, 255, 0.5);
        }
        
        .btn-submit {
            background-color: #00aaff;
            border: none;
            color: white;
            padding: 12px 25px;
            font-size: 18px;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-submit:hover {
            background-color: #0088cc;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        .btn-cancel {
            background-color: #555;
            border: none;
            color: white;
            padding: 12px 25px;
            font-size: 18px;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-cancel:hover {
            background-color: #444;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        .success-message,
        .error-message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
            animation: fadeIn 0.5s ease;
        }
        
        .success-message {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid #28a745;
        }
        
        .error-message {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        
        .user-info {
            background-color: #333;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .user-info p {
            margin-bottom: 5px;
        }
        
        .user-info strong {
            color: #00aaff;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Cor branca para saudação do usuário na navbar */
        .nav-link-user .d-none.d-lg-inline-block {
            color: #ffffff !important; /* Branco, !important para garantir prioridade */
        }
    </style>
</head>
<body>
    <div id="app">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm">
                    
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">Visão Geral</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>

                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li class="active"><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1>Editar Perfil</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item active"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item">Editar Perfil</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <div class="profile-container">
                            <h2 class="profile-title">Informações do Perfil</h2>
                            
                            <?php if (!empty($mensagem)): ?>
                                <div class="<?php echo $tipo_mensagem === 'success' ? 'success-message' : 'error-message'; ?>">
                                    <?php echo $mensagem; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="user-info">
                                <p><strong>Nome:</strong> <?php echo $nome_usuario; ?></p>
                                <p><strong>Email:</strong> <?php echo $email_usuario; ?></p>
                                <p><strong>Nível de Acesso:</strong> <?php echo ucfirst($nivel_usuario); ?></p>
                            </div>
                            
                            <form action="editar-perfil.php" method="POST" enctype="multipart/form-data">
                                <div class="avatar-container">
                                    <div class="avatar-preview">
                                        <img src="<?php echo $avatar_usuario; ?>" alt="Avatar" id="avatar-preview-img">
                                    </div>
                                    <div class="form-group">
                                        <label for="avatar">Alterar Avatar:</label>
                                        <input type="file" name="avatar" id="avatar" class="form-control" accept="image/*">
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nome">Nome:</label>
                                            <input type="text" name="nome" id="nome" class="form-control" value="<?php echo $nome_usuario; ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email">Email:</label>
                                            <input type="email" name="email" id="email" class="form-control" value="<?php echo $email_usuario; ?>" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="senha_atual">Senha Atual:</label>
                                            <input type="password" name="senha_atual" id="senha_atual" class="form-control" placeholder="Digite sua senha atual para confirmar as alterações" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nova_senha">Nova Senha (opcional):</label>
                                            <input type="password" name="nova_senha" id="nova_senha" class="form-control" placeholder="Deixe em branco para manter a senha atual">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <a href="painel.php" class="btn-cancel">Cancelar</a>
                                    <button type="submit" class="btn-submit">Salvar Alterações</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Preview de avatar
        document.getElementById('avatar').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('avatar-preview-img').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
