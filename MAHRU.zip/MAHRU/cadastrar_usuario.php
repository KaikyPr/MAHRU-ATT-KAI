<?php
session_start();

// Verificar se o usuário está logado e é administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_nivel'] !== 'admin') {
    // Redirecionar para o painel ou mostrar mensagem de erro
    $_SESSION['error_message'] = "Acesso restrito a administradores!";
    header('Location: painel.php');
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Obter informações do usuário logado
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar formulário de cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha = $_POST['senha'];
    $nivel = filter_input(INPUT_POST, 'nivel', FILTER_SANITIZE_SPECIAL_CHARS);
    
    // Validar dados
    if (empty($nome) || empty($email) || empty($senha) || empty($nivel)) {
        $mensagem = "Todos os campos são obrigatórios!";
        $tipo_mensagem = "error";
    } else {
        // Verificar se o email já existe
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        if ($stmt->fetchColumn() > 0) {
            $mensagem = "Este email já está cadastrado!";
            $tipo_mensagem = "error";
        } else {
            // Processar upload de avatar (se fornecido)
            $caminho_avatar = null;
            
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $avatar_nome = $_FILES['avatar']['name'];
                $avatar_tmp = $_FILES['avatar']['tmp_name'];
                $avatar_ext = strtolower(pathinfo($avatar_nome, PATHINFO_EXTENSION));
                
                // Verificar extensão
                $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array($avatar_ext, $extensoes_permitidas)) {
                    // Criar diretório de avatares se não existir
                    $diretorio_avatar = 'uploads/avatares/';
                    if (!is_dir($diretorio_avatar)) {
                        mkdir($diretorio_avatar, 0755, true);
                    }
                    
                    // Gerar nome único para o arquivo
                    $novo_nome = uniqid('avatar_') . '.' . $avatar_ext;
                    $caminho_avatar = $diretorio_avatar . $novo_nome;
                    
                    // Mover o arquivo
                    move_uploaded_file($avatar_tmp, $caminho_avatar);
                }
            }
            
            // Inserir novo usuário
            try {
                $sql = "INSERT INTO usuarios (nome, email, senha, nivel, avatar) VALUES (:nome, :email, :senha, :nivel, :avatar)";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':senha', $senha);
                $stmt->bindParam(':nivel', $nivel);
                $stmt->bindParam(':avatar', $caminho_avatar);
                
                if ($stmt->execute()) {
                    $mensagem = "Usuário cadastrado com sucesso!";
                    $tipo_mensagem = "success";
                    
                    // Limpar formulário
                    $nome = $email = $senha = "";
                    $nivel = "usuario";
                } else {
                    $mensagem = "Erro ao cadastrar usuário!";
                    $tipo_mensagem = "error";
                }
            } catch (PDOException $e) {
                $mensagem = "Erro no banco de dados: " . $e->getMessage();
                $tipo_mensagem = "error";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Cadastrar Usuário - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <style>
        /* Estilos adicionais específicos para esta página */
        .form-container {
            background-color: #2a2a2a;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .form-title {
            color: #00aaff;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #444;
        }
        
        .avatar-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .avatar-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 15px;
            border: 3px solid #00aaff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #333;
        }
        
        .avatar-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .avatar-preview i {
            font-size: 80px;
            color: #555;
        }
        
        .admin-badge {
            display: inline-block;
            background-color: #dc3545;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div id="app">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm">
                        
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">Visão Geral</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <li class="menu-header">Administração</li>
                        <li class="active"><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1>Cadastrar Novo Usuário <span class="admin-badge">Acesso Administrativo</span></h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item active"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item">Cadastrar Usuário</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <div class="form-container">
                            <h2 class="form-title">Preencha as informações do novo usuário</h2>
                            
                            <?php if (!empty($mensagem)): ?>
                                <div class="<?php echo $tipo_mensagem === 'success' ? 'success-message' : 'error-message'; ?>">
                                    <?php echo $mensagem; ?>
                                </div>
                            <?php endif; ?>
                            
                            <form action="cadastrar_usuario.php" method="POST" enctype="multipart/form-data">
                                <div class="avatar-container">
                                    <div class="avatar-preview">
                                        <i class="fas fa-user" id="avatar-icon"></i>
                                        <img src="" alt="Avatar Preview" id="avatar-preview-img" style="display: none;">
                                    </div>
                                    <div class="form-group">
                                        <label for="avatar">Avatar (opcional):</label>
                                        <input type="file" name="avatar" id="avatar" class="form-control" accept="image/*">
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nome">Nome:</label>
                                            <input type="text" name="nome" id="nome" class="form-control" value="<?php echo isset($nome) ? $nome : ''; ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email">Email:</label>
                                            <input type="email" name="email" id="email" class="form-control" value="<?php echo isset($email) ? $email : ''; ?>" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="senha">Senha:</label>
                                            <input type="password" name="senha" id="senha" class="form-control" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nivel">Nível de Acesso:</label>
                                            <select name="nivel" id="nivel" class="form-select" required>
                                                <option value="usuario" <?php echo (isset($nivel) && $nivel === 'usuario') ? 'selected' : ''; ?>>Usuário</option>
                                                <option value="admin" <?php echo (isset($nivel) && $nivel === 'admin') ? 'selected' : ''; ?>>Administrador</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <a href="painel.php" class="btn-cancel">Cancelar</a>
                                    <button type="submit" class="btn-submit">Cadastrar Usuário</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Preview de avatar
        document.getElementById('avatar').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const previewImg = document.getElementById('avatar-preview-img');
                    previewImg.src = e.target.result;
                    previewImg.style.display = 'block';
                    document.getElementById('avatar-icon').style.display = 'none';
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
