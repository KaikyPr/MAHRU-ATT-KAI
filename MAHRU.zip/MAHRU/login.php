<?php
session_start();
require_once("db/conexao.php");

// Verificar se já está logado
if (isset($_SESSION['usuario_id'])) {
    header('Location: painel.php');
    exit;
}

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email']) && isset($_POST['senha'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $senha = $_POST['senha'];
        
        try {
            $sql = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verificar senha (sem hash para simplificar)
                if ($senha === $usuario['senha']) {
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome'];
                    $_SESSION['usuario_nivel'] = $usuario['nivel'];
                    
                    header('Location: painel.php');
                    exit;
                } else {
                    $mensagem = "Senha incorreta!";
                    $tipo_mensagem = "error";
                }
            } else {
                $mensagem = "Usuário não encontrado!";
                $tipo_mensagem = "error";
            }
        } catch (PDOException $e) {
            $mensagem = "Erro no banco de dados: " . $e->getMessage();
            $tipo_mensagem = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Login - MAHRU</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <style>
        /* Reset de margens e padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #121212;
            color: white;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('img/LOGO.png') center/cover;
        }

        .container-login {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }

        .wrapper-login {
            width: 100%;
            background-color: #2a2a2a;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
            overflow: hidden;
        }

        .title {
            background-color: #00aaff;
            color: white;
            font-size: 30px;
            font-weight: 600;
            text-align: center;
            line-height: 100px;
            border-radius: 15px 15px 0 0;
            user-select: none;
        }

        .form-login {
            padding: 30px 25px 25px 25px;
        }

        .row {
            position: relative;
            margin-bottom: 25px;
        }

        .row i {
            position: absolute;
            color: #00aaff;
            font-size: 20px;
            top: 50%;
            transform: translateY(-50%);
            left: 15px;
        }

        .form-login input {
            width: 100%;
            height: 50px;
            padding: 0 20px 0 45px;
            border: 1px solid #444;
            outline: none;
            font-size: 16px;
            border-radius: 8px;
            background-color: #333;
            color: white;
            transition: all 0.3s ease;
        }

        .form-login input:focus {
            border-color: #00aaff;
            box-shadow: 0 0 10px rgba(0, 170, 255, 0.3);
        }

        .form-login input::placeholder {
            color: #999;
        }

        .button input {
            background-color: #00aaff;
            border: none;
            color: white;
            font-size: 18px;
            font-weight: 500;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            padding: 0;
        }

        .button input:hover {
            background-color: #0088cc;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #00aaff;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .back-link a:hover {
            text-decoration: underline;
            color: #0088cc;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
        }

        .alert-success {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid #28a745;
        }

        .alert-error {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            border: 1px solid #dc3545;
        }

        /* Animação */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .wrapper-login {
            animation: fadeIn 0.5s ease;
        }
    </style>
</head>
<body>
    <div class="container-login">
        <div class="wrapper-login">
            <div class="title">
                <span>MAHRU</span>
            </div>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="login.php" class="form-login">
                <div class="row">
                    <i class="fa-solid fa-user"></i>
                    <input type="text" name="email" placeholder="E-mail" required>
                </div>
                <div class="row">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" placeholder="Senha" name="senha" required>
                </div>

                <div class="row button">
                    <input type="submit" value="Acessar">
                </div>
                
                <div class="back-link">
                    <a href="index.html"><i class="fas fa-arrow-left"></i> Voltar para a página inicial</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
