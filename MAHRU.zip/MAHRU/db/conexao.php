<?php
$servidor = 'http://localhost';  // Endereço do servidor MySQL remoto
$usuario = 'root';  // Usuário do banco de dados remoto
$senha = '';  // Senha do banco de dados remoto
$banco = 'MAHRU';  // Nome do banco de dados remoto

try {
    // Correção: Usar as variáveis corretas
    $pdo = new PDO("mysql:host=$servidor;dbname=$banco", $usuario, $senha);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Verificar se a tabela de usuários existe, se não, criar
    $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        senha VARCHAR(100) NOT NULL,
        nivel VARCHAR(20) NOT NULL DEFAULT 'usuario',
        avatar VARCHAR(255) DEFAULT NULL,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Verificar se existe pelo menos um usuário admin
    $query = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE nivel = 'admin'");
    $count = $query->fetchColumn();
    
    if ($count == 0) {
        // Criar usuário admin padrão
        $nome = 'Administrador';
        $email = 'admin@mahru.com';
        $senha = 'admin';
        $nivel = 'admin';
        
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, nivel) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $email, $senha, $nivel]);
    }
    
    // Verificar se a tabela de hacks existe, se não, criar
    $pdo->exec("CREATE TABLE IF NOT EXISTS hacks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        descricao TEXT NOT NULL,
        piso INT NOT NULL,
        tipo VARCHAR(20) NOT NULL,
        imagem VARCHAR(255) NOT NULL,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}
?>
