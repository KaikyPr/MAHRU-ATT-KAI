<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar formulário de cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_SPECIAL_CHARS);
    $piso = filter_input(INPUT_POST, 'piso', FILTER_VALIDATE_INT);
    $tipo = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_SPECIAL_CHARS);
    
    // Validar dados
    if (empty($nome) || empty($descricao) || empty($piso) || empty($tipo)) {
        $mensagem = "Todos os campos são obrigatórios!";
        $tipo_mensagem = "error";
    } else {
        // Processar upload de imagem
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $imagem_nome = $_FILES['imagem']['name'];
            $imagem_tmp = $_FILES['imagem']['tmp_name'];
            $imagem_ext = strtolower(pathinfo($imagem_nome, PATHINFO_EXTENSION));
            
            // Verificar extensão
            $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($imagem_ext, $extensoes_permitidas)) {
                // Gerar nome único para o arquivo
                $novo_nome = uniqid() . '.' . $imagem_ext;
                $caminho_imagem = 'uploads/' . $novo_nome;
                
                // Mover o arquivo
                if (move_uploaded_file($imagem_tmp, $caminho_imagem)) {
                    // Inserir no banco de dados
                    $sql = "INSERT INTO hacks (nome, descricao, piso, tipo, imagem) VALUES (:nome, :descricao, :piso, :tipo, :imagem)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':descricao', $descricao);
                    $stmt->bindParam(':piso', $piso);
                    $stmt->bindParam(':tipo', $tipo);
                    $stmt->bindParam(':imagem', $caminho_imagem);
                    
                    if ($stmt->execute()) {
                        $mensagem = "Hack cadastrado com sucesso!";
                        $tipo_mensagem = "success";
                        
                        // Limpar formulário
                        $nome = $descricao = "";
                        $piso = 1;
                        $tipo = "interno";
                    } else {
                        $mensagem = "Erro ao cadastrar hack!";
                        $tipo_mensagem = "error";
                    }
                } else {
                    $mensagem = "Erro ao fazer upload da imagem!";
                    $tipo_mensagem = "error";
                }
            } else {
                $mensagem = "Formato de imagem não permitido! Use JPG, JPEG, PNG ou GIF.";
                $tipo_mensagem = "error";
            }
        } else {
            $mensagem = "Selecione uma imagem para o hack!";
            $tipo_mensagem = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Cadastrar Hack - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!-- Overlay de carregamento -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <!-- Removido a duplicidade, mantendo apenas uma instância do nome -->
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li class="active"><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header animate__animated animate__fadeInDown">
                        <h1>Cadastrar Novo Hack</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item active">Cadastrar Hack</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <?php if (!empty($mensagem)): ?>
                            <div class="<?php echo $tipo_mensagem === 'success' ? 'success-message' : 'error-message'; ?> animate__animated animate__fadeIn">
                                <?php echo $mensagem; ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-container animate__animated animate__fadeInUp">
                            <h2 class="form-title">Preencha as informações do hack</h2>
                            
                            <form action="cadastrar_hack.php" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nome">Nome do Hack:</label>
                                            <input type="text" name="nome" id="nome" class="form-control" value="<?php echo isset($nome) ? $nome : ''; ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="piso">Piso:</label>
                                            <select name="piso" id="piso" class="form-select" required>
                                                <option value="1" <?php echo (isset($piso) && $piso == 1) ? 'selected' : ''; ?>>Piso 1</option>
                                                <option value="2" <?php echo (isset($piso) && $piso == 2) ? 'selected' : ''; ?>>Piso 2</option>
                                                <option value="3" <?php echo (isset($piso) && $piso == 3) ? 'selected' : ''; ?>>Piso 3</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <textarea name="descricao" id="descricao" class="form-control" rows="4" required><?php echo isset($descricao) ? $descricao : ''; ?></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="tipo">Tipo:</label>
                                            <select name="tipo" id="tipo" class="form-select" required>
                                                <option value="interno" <?php echo (isset($tipo) && $tipo === 'interno') ? 'selected' : ''; ?>>Interno</option>
                                                <option value="externo" <?php echo (isset($tipo) && $tipo === 'externo') ? 'selected' : ''; ?>>Externo</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="imagem">Imagem:</label>
                                            <input type="file" name="imagem" id="imagem" class="form-control" accept="image/*" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="image-preview-container text-center mb-4" style="display: none;">
                                    <h4 class="mb-3">Pré-visualização da Imagem</h4>
                                    <div class="image-preview">
                                        <img id="preview-img" src="#" alt="Preview" style="max-width: 100%; max-height: 300px; border-radius: 10px;">
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between mt-4">
                                    <a href="index.php" class="btn-cancel btn-hover-effect mahru-link">
                                        <i class="fas fa-arrow-left me-2"></i> Voltar
                                    </a>
                                    <button type="submit" class="btn-submit btn-hover-effect">
                                        <i class="fas fa-save me-2"></i> Cadastrar Hack
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Garantir que a animação de carregamento seja exibida por pelo menos 1 segundo
        document.addEventListener('DOMContentLoaded', function() {
            // Forçar exibição do loading por pelo menos 1 segundo
            document.getElementById('loading-overlay').style.display = 'flex';
            document.getElementById('app').classList.add('hidden-content');
            
            setTimeout(function() {
                document.getElementById('loading-overlay').classList.add('fade-out');
                document.getElementById('app').classList.remove('hidden-content');
                
                setTimeout(function() {
                    document.getElementById('loading-overlay').style.display = 'none';
                }, 500);
            }, 1000); // Forçar 1 segundo de carregamento
        });
        
        // Interceptar todos os cliques em links para mostrar animação de carregamento
        document.addEventListener('click', function(e) {
            // Verificar se o clique foi em um link interno
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
                
                // Verificar se é um link interno (não é # e está no mesmo domínio)
                if (link.getAttribute('href') && 
                    link.getAttribute('href') !== '#' && 
                    link.hostname === window.location.hostname &&
                    !link.classList.contains('dropdown-toggle') && // Ignorar toggles de dropdown
                    !link.hasAttribute('data-toggle')) { // Ignorar toggles de sidebar
                    
                    e.preventDefault();
                    
                    // Mostrar overlay de carregamento
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const app = document.getElementById('app');
                    
                    loadingOverlay.classList.remove('fade-out');
                    loadingOverlay.style.display = 'flex';
                    app.classList.add('hidden-content');
                    
                    // Redirecionar após 1 segundo
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 1000);
                }
            }
        });
        
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Preview de imagem
        document.getElementById('imagem').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview-img').src = e.target.result;
                    document.querySelector('.image-preview-container').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
        
        // Efeito de hover nos inputs
        const inputs = document.querySelectorAll('.form-control, .form-select');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('input-focus');
            });
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('input-focus');
            });
        });
    </script>
</body>
</html>
