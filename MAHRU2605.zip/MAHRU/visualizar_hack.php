<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');  // Redireciona para a página de login
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Verifica se o ID do hack foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$hack_id = (int)$_GET['id'];

// Busca os dados do hack
$sql = "SELECT * FROM hacks WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $hack_id);
$stmt->execute();

$hack = $stmt->fetch(PDO::FETCH_ASSOC);

// Se o hack não existir, redireciona para a página inicial
if (!$hack) {
    header('Location: index.php');
    exit;
}

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Visualizar Hack - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!-- Overlay de carregamento -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <!-- Removido a duplicidade, mantendo apenas uma instância do nome -->
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li class="active"><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header animate__animated animate__fadeInDown">
                        <h1>Detalhes do Hack</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item"><a href="index.php">Visualizar Hacks</a></div>
                            <div class="breadcrumb-item active">Detalhes</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <div class="hack-details-container animate__animated animate__fadeInUp">
                            <div class="row">
                                <div class="col-lg-5">
                                    <div class="hack-image-container">
                                        <img src="<?php echo htmlspecialchars($hack['imagem']); ?>" alt="<?php echo htmlspecialchars($hack['nome']); ?>" class="img-fluid rounded shadow">
                                    </div>
                                </div>
                                
                                <div class="col-lg-7">
                                    <div class="hack-info-container">
                                        <h2 class="hack-title"><?php echo htmlspecialchars($hack['nome']); ?></h2>
                                        
                                        <div class="hack-meta">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="meta-item">
                                                        <span class="meta-label">Piso</span>
                                                        <span class="meta-value"><?php echo htmlspecialchars($hack['piso']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="meta-item">
                                                        <span class="meta-label">Tipo</span>
                                                        <span class="meta-value"><?php echo ucfirst(htmlspecialchars($hack['tipo'])); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="meta-item">
                                                        <span class="meta-label">Data de Cadastro</span>
                                                        <span class="meta-value">
                                                            <?php 
                                                                if (isset($hack['data_cadastro'])) {
                                                                    echo date('d/m/Y', strtotime($hack['data_cadastro']));
                                                                } else {
                                                                    echo "N/A";
                                                                }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="hack-description">
                                            <h4>Descrição</h4>
                                            <p><?php echo nl2br(htmlspecialchars($hack['descricao'])); ?></p>
                                        </div>
                                        
                                        <div class="hack-actions">
                                            <a href="index.php" class="btn-cancel btn-hover-effect mahru-link">
                                                <i class="fas fa-arrow-left me-2"></i> Voltar
                                            </a>
                                            <a href="editar_hack.php?id=<?php echo $hack_id; ?>" class="btn-edit btn-hover-effect mahru-link">
                                                <i class="fas fa-edit me-2"></i> Editar
                                            </a>
                                            <button class="btn-delete btn-hover-effect" onclick="openDeleteModal()">
                                                <i class="fas fa-trash me-2"></i> Excluir
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Modal de confirmação de exclusão -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirmar Exclusão</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza que deseja excluir o hack "<?php echo htmlspecialchars($hack['nome']); ?>"?</p>
                    <p class="text-danger"><strong>Atenção:</strong> Esta ação não pode ser desfeita.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <a href="excluir_hack.php?id=<?php echo $hack_id; ?>&confirm=1" class="btn btn-danger">Excluir</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Garantir que a animação de carregamento seja exibida por pelo menos 1 segundo
        document.addEventListener('DOMContentLoaded', function() {
            // Forçar exibição do loading por pelo menos 1 segundo
            document.getElementById('loading-overlay').style.display = 'flex';
            document.getElementById('app').classList.add('hidden-content');
            
            setTimeout(function() {
                document.getElementById('loading-overlay').classList.add('fade-out');
                document.getElementById('app').classList.remove('hidden-content');
                
                setTimeout(function() {
                    document.getElementById('loading-overlay').style.display = 'none';
                }, 500);
            }, 1000); // Forçar 1 segundo de carregamento
        });
        
        // Interceptar todos os cliques em links para mostrar animação de carregamento
        document.addEventListener('click', function(e) {
            // Verificar se o clique foi em um link interno
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
                
                // Verificar se é um link interno (não é # e está no mesmo domínio)
                if (link.getAttribute('href') && 
                    link.getAttribute('href') !== '#' && 
                    link.hostname === window.location.hostname &&
                    !link.classList.contains('dropdown-toggle') && // Ignorar toggles de dropdown
                    !link.hasAttribute('data-toggle') && // Ignorar toggles de sidebar
                    !link.hasAttribute('data-bs-toggle')) { // Ignorar toggles de modal
                    
                    e.preventDefault();
                    
                    // Mostrar overlay de carregamento
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const app = document.getElementById('app');
                    
                    loadingOverlay.classList.remove('fade-out');
                    loadingOverlay.style.display = 'flex';
                    app.classList.add('hidden-content');
                    
                    // Redirecionar após 1 segundo
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 1000);
                }
            }
        });
        
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Modal de exclusão
        function openDeleteModal() {
            var deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }
    </script>
</body>
</html>
