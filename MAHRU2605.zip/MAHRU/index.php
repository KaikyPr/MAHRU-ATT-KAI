<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');  // Redireciona para a página de login
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Inicializa filtros
$piso_filter = isset($_GET['piso']) ? (int)$_GET['piso'] : 0;
$tipo_filter = isset($_GET['tipo']) ? $_GET['tipo'] : '';
$search_term = isset($_GET['search']) ? $_GET['search'] : '';

// Constrói a consulta SQL com base nos filtros
$sql = "SELECT * FROM hacks WHERE 1=1";
$params = [];

if ($piso_filter > 0) {
    $sql .= " AND piso = :piso";
    $params[':piso'] = $piso_filter;
}

if (!empty($tipo_filter)) {
    $sql .= " AND tipo = :tipo";
    $params[':tipo'] = $tipo_filter;
}

if (!empty($search_term)) {
    $sql .= " AND (nome LIKE :search OR descricao LIKE :search)";
    $params[':search'] = "%$search_term%";
}

$sql .= " ORDER BY piso, tipo";

// Prepara e executa a consulta
$stmt = $pdo->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$hacks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Agrupa os hacks por piso
$hacks_by_piso = [
    1 => ['interno' => [], 'externo' => []],
    2 => ['interno' => [], 'externo' => []],
    3 => ['interno' => [], 'externo' => []]
];

foreach ($hacks as $hack) {
    $piso = $hack['piso'];
    $tipo = $hack['tipo'];
    if (isset($hacks_by_piso[$piso][$tipo])) {
        $hacks_by_piso[$piso][$tipo][] = $hack;
    }
}

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Mensagens de erro/sucesso
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Visualizar Hacks - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!-- Overlay de carregamento -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <!-- Removido a duplicidade, mantendo apenas uma instância do nome -->
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li class="active"><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1>Mapeamento de Hacks de Rede UNESC</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item active">Visualizar Hacks</div>
                        </div>
                    </div>
                    
                    <?php if (isset($success_message)): ?>
                        <div class="success-message animate__animated animate__fadeIn"><?php echo $success_message; ?></div>
                    <?php endif; ?>

                    <?php if (isset($error_message)): ?>
                        <div class="error-message animate__animated animate__fadeIn"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <!-- Filtros -->
                    <div class="filters-container">
                        <h3 class="filters-title">Filtrar Hacks</h3>
                        <form class="filters-form" action="index.php" method="GET">
                            <div class="filter-group">
                                <label for="piso">Piso:</label>
                                <select id="piso" name="piso" class="form-select">
                                    <option value="0" <?php echo $piso_filter == 0 ? 'selected' : ''; ?>>Todos</option>
                                    <option value="1" <?php echo $piso_filter == 1 ? 'selected' : ''; ?>>Piso 1</option>
                                    <option value="2" <?php echo $piso_filter == 2 ? 'selected' : ''; ?>>Piso 2</option>
                                    <option value="3" <?php echo $piso_filter == 3 ? 'selected' : ''; ?>>Piso 3</option>
                                </select>
                            </div>
                            <div class="filter-group">
                                <label for="tipo">Tipo:</label>
                                <select id="tipo" name="tipo" class="form-select">
                                    <option value="" <?php echo $tipo_filter == '' ? 'selected' : ''; ?>>Todos</option>
                                    <option value="interno" <?php echo $tipo_filter == 'interno' ? 'selected' : ''; ?>>Interno</option>
                                    <option value="externo" <?php echo $tipo_filter == 'externo' ? 'selected' : ''; ?>>Externo</option>
                                </select>
                            </div>
                            <div class="filter-group">
                                <label for="search">Buscar:</label>
                                <input type="text" id="search" name="search" class="form-control" placeholder="Nome ou descrição" value="<?php echo htmlspecialchars($search_term); ?>">
                            </div>
                            <div class="filter-buttons">
                                <button type="submit" class="btn btn-primary btn-hover-effect mahru-link">
                                    <i class="fas fa-filter me-2"></i> Filtrar
                                </button>
                                <a href="index.php" class="btn btn-secondary btn-hover-effect mahru-link">
                                    <i class="fas fa-undo me-2"></i> Limpar
                                </a>
                            </div>
                        </form>
                    </div>

                    <?php if (empty($hacks)): ?>
                        <div class="no-hacks-message animate__animated animate__fadeIn">
                            <?php if (!empty($search_term) || $piso_filter > 0 || !empty($tipo_filter)): ?>
                                <i class="fas fa-search me-2"></i> Nenhum hack encontrado com os filtros selecionados.
                            <?php else: ?>
                                <i class="fas fa-info-circle me-2"></i> Você não tem hacks cadastrados.
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <?php for ($piso = 1; $piso <= 3; $piso++): ?>
                            <?php 
                            $has_interno = !empty($hacks_by_piso[$piso]['interno']);
                            $has_externo = !empty($hacks_by_piso[$piso]['externo']);
                            
                            // Pula este piso se não tiver hacks ou se estiver filtrando por outro piso
                            if (($piso_filter > 0 && $piso_filter != $piso) || (!$has_interno && !$has_externo)) {
                                continue;
                            }
                            ?>
                            
                            <div class="piso-section animate__animated animate__fadeIn">
                                <h3>Piso <?php echo $piso; ?></h3>
                                
                                <?php if ($has_interno && (empty($tipo_filter) || $tipo_filter == 'interno')): ?>
                                    <div class="tipo-section">
                                        <h4>Interno</h4>
                                        <div class="row">
                                            <?php foreach ($hacks_by_piso[$piso]['interno'] as $hack): ?>
                                                <div class="col-lg-4 col-md-6 mb-4">
                                                    <div class="hack-card animate__animated animate__fadeInUp">
                                                        <div class="hack-badges">
                                                            <span class="badge badge-piso">Piso <?php echo $hack['piso']; ?></span>
                                                            <span class="badge badge-tipo">Interno</span>
                                                        </div>
                                                        <h5><?php echo htmlspecialchars($hack['nome']); ?></h5>
                                                        <p class="text-muted"><?php echo htmlspecialchars(substr($hack['descricao'], 0, 100)) . (strlen($hack['descricao']) > 100 ? '...' : ''); ?></p>
                                                        <div class="d-flex justify-content-center gap-2">
                                                            <a href="visualizar_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn">
                                                                <i class="fas fa-eye me-1"></i> Ver
                                                            </a>
                                                            <a href="editar_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn btn-edit">
                                                                <i class="fas fa-edit me-1"></i> Editar
                                                            </a>
                                                            <a href="excluir_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn btn-delete" onclick="return confirm('Tem certeza que deseja excluir este hack?');">
                                                                <i class="fas fa-trash me-1"></i> Excluir
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($has_externo && (empty($tipo_filter) || $tipo_filter == 'externo')): ?>
                                    <div class="tipo-section">
                                        <h4>Externo</h4>
                                        <div class="row">
                                            <?php foreach ($hacks_by_piso[$piso]['externo'] as $hack): ?>
                                                <div class="col-lg-4 col-md-6 mb-4">
                                                    <div class="hack-card animate__animated animate__fadeInUp">
                                                        <div class="hack-badges">
                                                            <span class="badge badge-piso">Piso <?php echo $hack['piso']; ?></span>
                                                            <span class="badge badge-tipo-externo">Externo</span>
                                                        </div>
                                                        <h5><?php echo htmlspecialchars($hack['nome']); ?></h5>
                                                        <p class="text-muted"><?php echo htmlspecialchars(substr($hack['descricao'], 0, 100)) . (strlen($hack['descricao']) > 100 ? '...' : ''); ?></p>
                                                        <div class="d-flex justify-content-center gap-2">
                                                            <a href="visualizar_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn">
                                                                <i class="fas fa-eye me-1"></i> Ver
                                                            </a>
                                                            <a href="editar_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn btn-edit">
                                                                <i class="fas fa-edit me-1"></i> Editar
                                                            </a>
                                                            <a href="excluir_hack.php?id=<?php echo $hack['id']; ?>" class="view-btn btn-delete" onclick="return confirm('Tem certeza que deseja excluir este hack?');">
                                                                <i class="fas fa-trash me-1"></i> Excluir
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endfor; ?>
                    <?php endif; ?>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Garantir que a animação de carregamento seja exibida por pelo menos 1 segundo
        document.addEventListener('DOMContentLoaded', function() {
            // Forçar exibição do loading por pelo menos 1 segundo
            document.getElementById('loading-overlay').style.display = 'flex';
            document.getElementById('app').classList.add('hidden-content');
            
            setTimeout(function() {
                document.getElementById('loading-overlay').classList.add('fade-out');
                document.getElementById('app').classList.remove('hidden-content');
                
                setTimeout(function() {
                    document.getElementById('loading-overlay').style.display = 'none';
                }, 500);
            }, 1000); // Forçar 1 segundo de carregamento
        });
        
        // Interceptar todos os cliques em links para mostrar animação de carregamento
        document.addEventListener('click', function(e) {
            // Verificar se o clique foi em um link interno
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
                
                // Verificar se é um link interno (não é # e está no mesmo domínio)
                if (link.getAttribute('href') && 
                    link.getAttribute('href') !== '#' && 
                    link.hostname === window.location.hostname &&
                    !link.classList.contains('dropdown-toggle') && // Ignorar toggles de dropdown
                    !link.hasAttribute('data-toggle')) { // Ignorar toggles de sidebar
                    
                    e.preventDefault();
                    
                    // Mostrar overlay de carregamento
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const app = document.getElementById('app');
                    
                    loadingOverlay.classList.remove('fade-out');
                    loadingOverlay.style.display = 'flex';
                    app.classList.add('hidden-content');
                    
                    // Redirecionar após 1 segundo
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 1000);
                }
            }
        });
        
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Efeito de hover nos cards
        const cards = document.querySelectorAll('.hack-card');
        cards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.classList.add('card-hover');
            });
            card.addEventListener('mouseleave', function() {
                this.classList.remove('card-hover');
            });
        });
    </script>
</body>
</html>
