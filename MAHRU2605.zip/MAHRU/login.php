<?php
session_start();
require_once("db/conexao.php");

// Verificar se já está logado
if (isset($_SESSION["usuario_id"])) {
    header("Location: painel.php");
    exit;
}

// Mensagens de erro/sucesso (agora serão tratadas principalmente via JS/AJAX para o reset)
$login_mensagem = "";
$login_tipo_mensagem = "";

// Processar login
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login_action"])) { // Adiciona verificação para diferenciar do reset
    if (isset($_POST["email"]) && isset($_POST["senha"])) {
        $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
        $senha = $_POST["senha"];
        
        try {
            $sql = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(":email", $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verificar senha usando password_verify
                if (isset($usuario["senha"]) && password_verify($senha, $usuario["senha"])) {
                    // Senha correta
                    $_SESSION["usuario_id"] = $usuario["id"];
                    $_SESSION["usuario_nome"] = $usuario["nome"];
                    $_SESSION["usuario_nivel"] = $usuario["nivel"];
                    $_SESSION["avatar_usuario"] = isset($usuario["avatar"]) && !empty($usuario["avatar"]) ? $usuario["avatar"] : "img/img-sem-foto.jpg";
                    
                    header("Location: painel.php");
                    exit;
                } else {
                    // Senha incorreta ou hash inválido
                    $login_mensagem = "Email ou Senha incorreta!"; // Mensagem genérica por segurança
                    $login_tipo_mensagem = "error";
                }
            } else {
                $login_mensagem = "Usuário não encontrado!";
                $login_tipo_mensagem = "error";
            }
        } catch (PDOException $e) {
            $login_mensagem = "Erro no banco de dados: " . $e->getMessage();
            $login_tipo_mensagem = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Login - MAHRU</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        /* Estilos gerais (mantidos) */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Arial', sans-serif; background-color: #121212; color: white; height: 100vh; display: flex; justify-content: center; align-items: center; background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('img/LOGO.png') center/cover; }
        .container-login { width: 100%; max-width: 400px; padding: 20px; }
        .wrapper-login { width: 100%; background-color: #2a2a2a; border-radius: 15px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6); overflow: hidden; animation: fadeIn 0.5s ease; }
        .title { background-color: #00aaff; color: white; font-size: 30px; font-weight: 600; text-align: center; line-height: 100px; border-radius: 15px 15px 0 0; user-select: none; }
        .form-login, .form-reset-request, .form-reset-password { padding: 30px 25px 25px 25px; }
        .row { position: relative; margin-bottom: 25px; }
        .row > i:first-child { position: absolute; color: #00aaff; font-size: 20px; top: 50%; transform: translateY(-50%); left: 15px; }
        .toggle-password { position: absolute; cursor: pointer; color: #999; font-size: 18px; top: 50%; transform: translateY(-50%); right: 15px; z-index: 2; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; height: 50px; padding: 0 20px 0 45px; border: 1px solid #444; outline: none; font-size: 16px; border-radius: 8px; background-color: #333; color: white; transition: all 0.3s ease;
        }
        input[type="password"] { padding-right: 45px; } /* Espaço para o ícone de olho */
        input:focus { border-color: #00aaff; box-shadow: 0 0 10px rgba(0, 170, 255, 0.3); }
        input::placeholder { color: #999; }
        .button input, .button button {
            width: 100%; height: 50px; background-color: #00aaff; border: none; color: white; font-size: 18px; font-weight: 500; letter-spacing: 1px; cursor: pointer; transition: all 0.3s ease; padding: 0; border-radius: 8px;
        }
        .button input:hover, .button button:hover { background-color: #0088cc; transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); }
        .back-link, .forgot-password-link, .login-link {
            text-align: center; margin-top: 20px; font-size: 14px;
        }
        .back-link a, .forgot-password-link a, .login-link a {
            color: #00aaff; text-decoration: none; transition: all 0.3s ease;
        }
        .back-link a:hover, .forgot-password-link a:hover, .login-link a:hover { text-decoration: underline; color: #0088cc; }
        .forgot-password-link { text-align: right; margin-bottom: 15px; margin-top: -10px; } /* Ajuste */
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 8px; text-align: center; font-weight: bold; }
        .alert-success { background-color: rgba(40, 167, 69, 0.2); color: #28a745; border: 1px solid #28a745; }
        .alert-error { background-color: rgba(220, 53, 69, 0.2); color: #dc3545; border: 1px solid #dc3545; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        .hidden { display: none; }
        .spinner { border: 4px solid rgba(255, 255, 255, 0.3); border-radius: 50%; border-top: 4px solid #00aaff; width: 20px; height: 20px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container-login">
        <div class="wrapper-login">
            <div class="title">
                <span id="form-title">MAHRU - Login</span>
            </div>
            
            <!-- Mensagem de erro/sucesso (geral para AJAX) -->
            <div id="message-area" class="alert hidden"></div>
            
            <!-- Formulário de Login (inicialmente visível) -->
            <form method="post" action="login.php" class="form-login" id="login-form">
                <input type="hidden" name="login_action" value="1"> <!-- Identificador para PHP -->
                <?php if (!empty($login_mensagem)): ?>
                    <div class="alert alert-<?php echo $login_tipo_mensagem; ?>">
                        <?php echo $login_mensagem; ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <i class="fa-solid fa-user"></i>
                    <input type="email" name="email" placeholder="E-mail" required>
                </div>
                <div class="row password-container">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" placeholder="Senha" name="senha" id="senha-login" required>
                    <i class="fa-solid fa-eye toggle-password" id="toggle-senha-login"></i>
                </div>
                <div class="forgot-password-link">
                    <a href="#" id="forgot-password-trigger">Esqueci minha senha</a>
                </div>
                <div class="row button">
                    <input type="submit" value="Acessar">
                </div>
                <div class="back-link">
                    <a href="index.html"><i class="fas fa-arrow-left"></i> Voltar para a página inicial</a>
                </div>
            </form>

            <!-- Formulário para Solicitar Reset (inicialmente oculto) -->
            <form class="form-reset-request hidden" id="reset-request-form">
                 <p style="text-align: center; margin-bottom: 20px; color: #ccc;">Digite seu e-mail para receber o código de recuperação.</p>
                <div class="row">
                    <i class="fa-solid fa-envelope"></i>
                    <input type="email" name="reset_email" id="reset_email" placeholder="Seu E-mail cadastrado" required>
                </div>
                <div class="row button">
                    <button type="submit" id="submit-request-btn">Enviar Código</button>
                </div>
                 <div class="login-link">
                    <a href="#" id="back-to-login-1"><i class="fas fa-arrow-left"></i> Voltar para o Login</a>
                </div>
            </form>

            <!-- Formulário para Inserir Código e Nova Senha (inicialmente oculto) -->
            <form class="form-reset-password hidden" id="reset-password-form">
                <input type="hidden" name="email_to_reset" id="email_to_reset"> <!-- Para enviar junto com o código -->
                <p style="text-align: center; margin-bottom: 20px; color: #ccc;">Digite o código recebido e sua nova senha.</p>
                <div class="row">
                    <i class="fa-solid fa-key"></i>
                    <input type="text" name="reset_code" id="reset_code" placeholder="Código de Recuperação" required>
                </div>
                <div class="row password-container">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="new_password" id="new_password" placeholder="Nova Senha" required>
                    <i class="fa-solid fa-eye toggle-password" id="toggle-new-password"></i>
                </div>
                 <div class="row password-container">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirmar Nova Senha" required>
                    <i class="fa-solid fa-eye toggle-password" id="toggle-confirm-password"></i>
                </div>
                <div class="row button">
                    <button type="submit" id="submit-reset-btn">Redefinir Senha</button>
                </div>
                 <div class="login-link">
                    <a href="#" id="back-to-login-2"><i class="fas fa-arrow-left"></i> Voltar para o Login</a>
                </div>
            </form>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('login-form');
            const resetRequestForm = document.getElementById('reset-request-form');
            const resetPasswordForm = document.getElementById('reset-password-form');
            const forgotPasswordLink = document.getElementById('forgot-password-trigger');
            const backToLoginLinks = document.querySelectorAll('#back-to-login-1, #back-to-login-2');
            const messageArea = document.getElementById('message-area');
            const formTitle = document.getElementById('form-title');
            const emailToResetInput = document.getElementById('email_to_reset');

            // --- Funções Auxiliares ---
            function showMessage(type, text) {
                messageArea.className = `alert alert-${type}`;
                messageArea.textContent = text;
                messageArea.classList.remove('hidden');
            }

            function hideMessage() {
                messageArea.classList.add('hidden');
                messageArea.textContent = '';
            }

            function showSpinner(button) {
                button.innerHTML = '<div class="spinner"></div>';
                button.disabled = true;
            }

            function hideSpinner(button, originalText) {
                button.innerHTML = originalText;
                button.disabled = false;
            }

            function switchForm(formToShow) {
                hideMessage();
                loginForm.classList.add('hidden');
                resetRequestForm.classList.add('hidden');
                resetPasswordForm.classList.add('hidden');
                formToShow.classList.remove('hidden');

                if (formToShow === loginForm) {
                    formTitle.textContent = 'MAHRU - Login';
                } else if (formToShow === resetRequestForm) {
                    formTitle.textContent = 'Recuperar Senha';
                } else {
                    formTitle.textContent = 'Redefinir Senha';
                }
            }

            // --- Toggle Senha (Login e Reset) ---
            function setupPasswordToggle(toggleId, passwordId) {
                const toggle = document.getElementById(toggleId);
                const password = document.getElementById(passwordId);
                if (toggle && password) {
                    toggle.addEventListener('click', function() {
                        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                        password.setAttribute('type', type);
                        this.classList.toggle('fa-eye');
                        this.classList.toggle('fa-eye-slash');
                    });
                }
            }
            setupPasswordToggle('toggle-senha-login', 'senha-login');
            setupPasswordToggle('toggle-new-password', 'new_password');
            setupPasswordToggle('toggle-confirm-password', 'confirm_password');

            // --- Event Listeners ---
            if (forgotPasswordLink) {
                forgotPasswordLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    switchForm(resetRequestForm);
                });
            }

            backToLoginLinks.forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    switchForm(loginForm);
                });
            });

            // AJAX - Solicitar Reset
            if (resetRequestForm) {
                resetRequestForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    hideMessage();
                    const email = document.getElementById('reset_email').value;
                    const button = document.getElementById('submit-request-btn');
                    const originalButtonText = button.textContent;
                    showSpinner(button);

                    fetch('ajax_request_reset.php', { // Script PHP a ser criado
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'email=' + encodeURIComponent(email)
                    })
                    .then(response => response.json())
                    .then(data => {
                        hideSpinner(button, originalButtonText);
                        if (data.success) {
                            // Mesmo que o email falhe, se data.success for true, o código foi gerado.
                            let messageType = "success"; // Assume sucesso por padrão
                            if (data.message.includes("[DEBUG: Código")) { // Verifica se é a mensagem de erro de envio com debug
                                messageType = "error"; // Mostra como erro para destacar o código
                            }
                            showMessage(messageType, data.message); // Mostra a mensagem (sucesso ou erro de envio destacado)
                            emailToResetInput.value = email; // Guarda o email para o próximo passo
                            switchForm(resetPasswordForm); // <<< MUDA PARA O FORMULÁRIO DE CÓDIGO AUTOMATICAMENTE
                        } else {
                            showMessage("error", data.message);
                        }
                    })
                    .catch(error => {
                        hideSpinner(button, originalButtonText);
                        showMessage('error', 'Ocorreu um erro de comunicação. Tente novamente.');
                        console.error('Erro:', error);
                    });
                });
            }

            // AJAX - Redefinir Senha
            if (resetPasswordForm) {
                resetPasswordForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    hideMessage();
                    const code = document.getElementById('reset_code').value;
                    const newPassword = document.getElementById('new_password').value;
                    const confirmPassword = document.getElementById('confirm_password').value;
                    const email = emailToResetInput.value; // Pega o email guardado
                    const button = document.getElementById('submit-reset-btn');
                    const originalButtonText = button.textContent;

                    if (newPassword !== confirmPassword) {
                        showMessage('error', 'As novas senhas não coincidem.');
                        return;
                    }
                    if (!email) {
                         showMessage('error', 'Erro: Email não encontrado. Tente solicitar o código novamente.');
                         return;
                    }

                    showSpinner(button);

                    const formData = new URLSearchParams();
                    formData.append('email', email);
                    formData.append('code', code);
                    formData.append('new_password', newPassword);

                    fetch('ajax_reset_password.php', { // Script PHP a ser criado
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        hideSpinner(button, originalButtonText);
                        if (data.success) {
                            showMessage('success', data.message + ' Você já pode fazer login.');
                            resetPasswordForm.reset(); // Limpa o formulário
                            // Opcional: Mudar para o form de login automaticamente após um delay
                            // setTimeout(() => switchForm(loginForm), 3000);
                        } else {
                            showMessage('error', data.message);
                        }
                    })
                    .catch(error => {
                        hideSpinner(button, originalButtonText);
                        showMessage('error', 'Ocorreu um erro de comunicação. Tente novamente.');
                        console.error('Erro:', error);
                    });
                });
            }

        });
    </script>
</body>
</html>

