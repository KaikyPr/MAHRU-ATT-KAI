<?php
session_start();
require_once("db/conexao.php");

header("Content-Type: application/json");

$response = ["success" => false, "message" => "Erro desconhecido."];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["email"])) {
    $email = filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL);

    if (!$email) {
        $response["message"] = "Formato de email inválido.";
        echo json_encode($response);
        exit;
    }

    try {
        // 1. Verificar se o email existe
        $sql_check = "SELECT id FROM usuarios WHERE email = :email LIMIT 1";
        $stmt_check = $pdo->prepare($sql_check);
        $stmt_check->bindParam(":email", $email);
        $stmt_check->execute();

        if ($stmt_check->rowCount() > 0) {
            $usuario = $stmt_check->fetch(PDO::FETCH_ASSOC);
            $user_id = $usuario["id"];

            // 2. Gerar código e expiração
            $reset_code = random_int(100000, 999999); // Código de 6 dígitos
            $expires_in_minutes = 15; // Código expira em 15 minutos
            $reset_expires = date("Y-m-d H:i:s", strtotime("+" . $expires_in_minutes . " minutes"));

            // 3. Salvar código e expiração no banco
            // ATENÇÃO: É necessário adicionar as colunas `reset_code` (VARCHAR ou INT) e `reset_expires` (DATETIME ou TIMESTAMP) na tabela `usuarios`
            // Exemplo SQL: ALTER TABLE usuarios ADD COLUMN reset_code VARCHAR(10) NULL, ADD COLUMN reset_expires DATETIME NULL;
            $sql_update = "UPDATE usuarios SET reset_code = :code, reset_expires = :expires WHERE id = :id";
            $stmt_update = $pdo->prepare($sql_update);
            $stmt_update->bindParam(":code", $reset_code);
            $stmt_update->bindParam(":expires", $reset_expires);
            $stmt_update->bindParam(":id", $user_id);

            if ($stmt_update->execute()) {
                // Código salvo com sucesso no banco, então a operação principal foi um sucesso.
                $response["success"] = true; 

                // 4. Tentar enviar o email
                $subject = "Seu Código de Recuperação de Senha - MAHRU";
                $message = "Olá,\n\nVocê solicitou a recuperação de senha para sua conta no MAHRU.\n\nSeu código de recuperação é: " . $reset_code . "\n\nEste código expirará em " . $expires_in_minutes . " minutos.\n\nSe você não solicitou isso, ignore este email.\n\nAtenciosamente,\nEquipe MAHRU";
                $headers = "From: nao-responda@mahru.com\r\n" . // Substitua pelo seu email
                           "Reply-To: nao-responda@mahru.com\r\n" .
                           "X-Mailer: PHP/" . phpversion();

                // ATENÇÃO: A função mail() depende da configuração do servidor PHP.
                // Para ambientes de produção, é recomendado usar bibliotecas como PHPMailer com SMTP.
                if (@mail($email, $subject, $message, $headers)) {
                    // Email enviado com sucesso
                    $response["message"] = "Um código de recuperação foi enviado para seu email (verifique spam). Ele expira em " . $expires_in_minutes . " minutos.";
                } else {
                    // Falha ao enviar email, mas o código está no banco.
                    error_log("Falha ao enviar email de recuperação para: " . $email . " Código: " . $reset_code); // Log do erro
                    $response["message"] = "Email encontrado, mas houve um erro ao enviar o código. Verifique as configurações do servidor de email. [DEBUG: Código " . $reset_code . "]"; // Mensagem de erro mais informativa
                    // Em produção, remova o [DEBUG: Código ...]
                }
            } else {
                $response["message"] = "Erro ao salvar o código de recuperação no banco de dados.";
            }

        } else {
            $response["message"] = "Email não encontrado em nossa base de dados.";
        }

    } catch (PDOException $e) {
        error_log("Erro PDO em ajax_request_reset: " . $e->getMessage());
        $response["message"] = "Erro no banco de dados ao processar a solicitação.";
    } catch (Exception $e) {
        error_log("Erro geral em ajax_request_reset: " . $e->getMessage());
        $response["message"] = "Ocorreu um erro inesperado.";
    }

} else {
    $response["message"] = "Requisição inválida.";
}

echo json_encode($response);
?>
