<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');  // Redireciona para a página de login
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Verifica se o ID do hack foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$hack_id = (int)$_GET['id'];

// Busca os dados do hack
$sql = "SELECT * FROM hacks WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $hack_id);
$stmt->execute();

$hack = $stmt->fetch(PDO::FETCH_ASSOC);

// Se o hack não existir, redireciona para a página inicial
if (!$hack) {
    header('Location: index.php');
    exit;
}

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Processar exclusão se confirmada
if (isset($_GET['confirm']) && $_GET['confirm'] == 1) {
    // Excluir o hack do banco de dados
    $sql = "DELETE FROM hacks WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $hack_id);
    
    if ($stmt->execute()) {
        // Remover a imagem se existir
        if ($hack['imagem'] && file_exists($hack['imagem']) && $hack['imagem'] != 'img/hack-default.jpg') {
            unlink($hack['imagem']);
        }
        
        // Definir mensagem de sucesso e redirecionar
        $_SESSION['success_message'] = "Hack excluído com sucesso!";
        header('Location: index.php');
        exit;
    } else {
        $_SESSION['error_message'] = "Erro ao excluir hack. Tente novamente.";
        header('Location: index.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Excluir Hack - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!-- Overlay de carregamento -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <!-- Removido a duplicidade, mantendo apenas uma instância do nome -->
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li class="active"><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header animate__animated animate__fadeInDown">
                        <h1>Excluir Hack</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item"><a href="index.php">Visualizar Hacks</a></div>
                            <div class="breadcrumb-item"><a href="visualizar_hack.php?id=<?php echo $hack_id; ?>">Detalhes</a></div>
                            <div class="breadcrumb-item active">Excluir</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <div class="delete-confirmation-container animate__animated animate__fadeInUp">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="hack-image-container">
                                        <img src="<?php echo htmlspecialchars($hack['imagem']); ?>" alt="<?php echo htmlspecialchars($hack['nome']); ?>" class="img-fluid rounded shadow">
                                    </div>
                                </div>
                                
                                <div class="col-lg-8">
                                    <div class="delete-confirmation-content">
                                        <div class="delete-icon">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </div>
                                        
                                        <h2 class="delete-title">Confirmar Exclusão</h2>
                                        
                                        <div class="hack-info-summary">
                                            <h3><?php echo htmlspecialchars($hack['nome']); ?></h3>
                                            <div class="hack-meta-summary">
                                                <span class="badge badge-piso">Piso <?php echo htmlspecialchars($hack['piso']); ?></span>
                                                <span class="badge <?php echo $hack['tipo'] === 'interno' ? 'badge-tipo' : 'badge-tipo-externo'; ?>">
                                                    <?php echo ucfirst(htmlspecialchars($hack['tipo'])); ?>
                                                </span>
                                            </div>
                                            <p class="delete-warning">
                                                Você está prestes a excluir permanentemente este hack. Esta ação não pode ser desfeita.
                                            </p>
                                        </div>
                                        
                                        <div class="delete-actions">
                                            <a href="visualizar_hack.php?id=<?php echo $hack_id; ?>" class="btn-cancel btn-hover-effect mahru-link">
                                                <i class="fas fa-arrow-left me-2"></i> Cancelar
                                            </a>
                                            <a href="excluir_hack.php?id=<?php echo $hack_id; ?>&confirm=1" class="btn-delete btn-hover-effect">
                                                <i class="fas fa-trash me-2"></i> Confirmar Exclusão
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Garantir que a animação de carregamento seja exibida por pelo menos 1 segundo
        document.addEventListener('DOMContentLoaded', function() {
            // Forçar exibição do loading por pelo menos 1 segundo
            document.getElementById('loading-overlay').style.display = 'flex';
            document.getElementById('app').classList.add('hidden-content');
            
            setTimeout(function() {
                document.getElementById('loading-overlay').classList.add('fade-out');
                document.getElementById('app').classList.remove('hidden-content');
                
                setTimeout(function() {
                    document.getElementById('loading-overlay').style.display = 'none';
                }, 500);
            }, 1000); // Forçar 1 segundo de carregamento
        });
        
        // Interceptar todos os cliques em links para mostrar animação de carregamento
        document.addEventListener('click', function(e) {
            // Verificar se o clique foi em um link interno
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
                
                // Verificar se é um link interno (não é # e está no mesmo domínio)
                if (link.getAttribute('href') && 
                    link.getAttribute('href') !== '#' && 
                    link.hostname === window.location.hostname &&
                    !link.classList.contains('dropdown-toggle') && // Ignorar toggles de dropdown
                    !link.hasAttribute('data-toggle')) { // Ignorar toggles de sidebar
                    
                    e.preventDefault();
                    
                    // Mostrar overlay de carregamento
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const app = document.getElementById('app');
                    
                    loadingOverlay.classList.remove('fade-out');
                    loadingOverlay.style.display = 'flex';
                    app.classList.add('hidden-content');
                    
                    // Redirecionar após 1 segundo
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 1000);
                }
            }
        });
        
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
    </script>
</body>
</html>
