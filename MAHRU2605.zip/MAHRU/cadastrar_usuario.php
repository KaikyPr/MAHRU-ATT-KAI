<?php
session_start();

// Verificar se o usuário está logado e é administrador
if (!isset($_SESSION["usuario_id"]) || $_SESSION["usuario_nivel"] !== "admin") {
    $_SESSION["error_message"] = "Acesso restrito a administradores!";
    header("Location: painel.php");
    exit;
}

// Conexão com o banco de dados
include("db/conexao.php");

// Obter informações do usuário logado (para a navbar/sidebar)
$query_admin = $pdo->query("SELECT nome, avatar FROM usuarios WHERE id = {$_SESSION["usuario_id"]}");
$admin_info = $query_admin->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $admin_info["nome"]; // Nome do admin logado
$avatar_usuario = isset($admin_info["avatar"]) && !empty($admin_info["avatar"]) ? $admin_info["avatar"] : "img/img-sem-foto.jpg";
$_SESSION["nome_usuario"] = $nome_usuario; // Atualiza sessão para header
$_SESSION["avatar_usuario"] = $avatar_usuario;

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar formulário de cadastro
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome_novo_usuario = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
    $email_novo_usuario = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $senha_novo_usuario = $_POST["senha"]; // ATENÇÃO: Senha em texto plano?
    $nivel_novo_usuario = filter_input(INPUT_POST, "nivel", FILTER_SANITIZE_SPECIAL_CHARS);
    
    // Validar dados
    if (empty($nome_novo_usuario) || empty($email_novo_usuario) || empty($senha_novo_usuario) || empty($nivel_novo_usuario)) {
        $mensagem = "Todos os campos são obrigatórios!";
        $tipo_mensagem = "error";
    } else {
        // Verificar se o email já existe
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = :email");
        $stmt_check->bindParam(":email", $email_novo_usuario);
        $stmt_check->execute();
        
        if ($stmt_check->fetchColumn() > 0) {
            $mensagem = "Este email já está cadastrado!";
            $tipo_mensagem = "error";
        } else {
            // Processar upload de avatar (se fornecido)
            $caminho_avatar_novo_usuario = "img/img-sem-foto.jpg"; // Padrão
            if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] == 0) {
                $avatar_nome = $_FILES["avatar"]["name"];
                $avatar_tmp = $_FILES["avatar"]["tmp_name"];
                $avatar_ext = strtolower(pathinfo($avatar_nome, PATHINFO_EXTENSION));
                
                $extensoes_permitidas = ["jpg", "jpeg", "png", "gif"];
                if (in_array($avatar_ext, $extensoes_permitidas)) {
                    $diretorio_avatar = "uploads/avatares/";
                    if (!is_dir($diretorio_avatar)) {
                        mkdir($diretorio_avatar, 0755, true);
                    }
                    $novo_nome_avatar = uniqid("avatar_") . "." . $avatar_ext;
                    $caminho_avatar_novo_usuario = $diretorio_avatar . $novo_nome_avatar;
                    
                    if (!move_uploaded_file($avatar_tmp, $caminho_avatar_novo_usuario)) {
                        $caminho_avatar_novo_usuario = "img/img-sem-foto.jpg"; // Falha no upload, volta ao padrão
                        $mensagem = "Erro ao fazer upload do avatar. Usuário será cadastrado com avatar padrão.";
                        $tipo_mensagem = "warning"; // Avisa sobre o avatar
                    }
                }
            }
            
            // Inserir novo usuário
            try {
                // Hashear a senha antes de salvar
                $hash_senha = password_hash($senha_novo_usuario, PASSWORD_DEFAULT);
                
                $sql_insert = "INSERT INTO usuarios (nome, email, senha, nivel, avatar) VALUES (:nome, :email, :senha, :nivel, :avatar)";
                $stmt_insert = $pdo->prepare($sql_insert);
                $stmt_insert->bindParam(":nome", $nome_novo_usuario);
                $stmt_insert->bindParam(":email", $email_novo_usuario);
                $stmt_insert->bindParam(":senha", $hash_senha); // Salva o hash
                $stmt_insert->bindParam(":nivel", $nivel_novo_usuario);
                $stmt_insert->bindParam(":avatar", $caminho_avatar_novo_usuario);
                
                if ($stmt_insert->execute()) {
                    $mensagem = "Usuário cadastrado com sucesso!";
                    $tipo_mensagem = "success";
                    // Limpar variáveis do formulário para não repopular
                    $nome_novo_usuario = $email_novo_usuario = $senha_novo_usuario = "";
                    $nivel_novo_usuario = "usuario"; 
                } else {
                    $mensagem = "Erro ao cadastrar usuário no banco de dados.";
                    $tipo_mensagem = "error";
                }
            } catch (PDOException $e) {
                $mensagem = "Erro no banco de dados: " . $e->getMessage();
                $tipo_mensagem = "error";
            }
        }
    }
}

// Define o título da página
$page_title = "Cadastrar Usuário - MAHRU";

// Inclui o cabeçalho padrão
include("includes/header.php");
?>

<!-- Estilos específicos da página -->
<style>
    .form-container {
        background-color: var(--card-bg);
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        max-width: 900px;
        margin: 20px auto;
        border-top: 3px solid var(--primary-color);
    }
    
    .form-title {
        color: var(--primary-color);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #444;
    }
    
    .avatar-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 30px;
    }
    
    .avatar-preview {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        overflow: hidden;
        margin-bottom: 15px;
        border: 3px solid var(--primary-color);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #333;
    }
    
    .avatar-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .avatar-preview i {
        font-size: 80px;
        color: #555;
    }
    
    .admin-badge {
        display: inline-block;
        background-color: var(--danger-color);
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 14px;
        margin-left: 10px;
    }

    .toggle-password {
        cursor: pointer;
        color: #999;
    }
    .toggle-password:hover {
        color: var(--primary-color);
    }
</style>

<!-- Conteúdo Principal da Página -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Cadastrar Novo Usuário <span class="admin-badge">Acesso Administrativo</span></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="painel.php">Visão Geral</a></div>
                <div class="breadcrumb-item">Cadastrar Usuário</div>
            </div>
        </div>
        
        <div class="section-body">
            <div class="form-container">
                <h2 class="form-title">Preencha as informações do novo usuário</h2>
                
                <?php if (!empty($mensagem)): ?>
                    <div class="alert <?php echo $tipo_mensagem === "success" ? "alert-success" : ($tipo_mensagem === "warning" ? "alert-warning" : "alert-danger"); ?> animate__animated animate__fadeIn">
                        <?php echo htmlspecialchars($mensagem); ?>
                    </div>
                <?php endif; ?>
                
                <form action="cadastrar_usuario.php" method="POST" enctype="multipart/form-data">
                    <div class="avatar-container">
                        <div class="avatar-preview">
                            <i class="fas fa-user" id="avatar-icon" style="display: block;"></i>
                            <img src="#" alt="Avatar Preview" id="avatar-preview-img" style="display: none;">
                        </div>
                        <div class="form-group">
                            <label for="avatar">Avatar (opcional):</label>
                            <input type="file" name="avatar" id="avatar" class="form-control" accept="image/*">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome">Nome:</label>
                                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo isset($nome_novo_usuario) ? htmlspecialchars($nome_novo_usuario) : ''; ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" name="email" id="email" class="form-control" value="<?php echo isset($email_novo_usuario) ? htmlspecialchars($email_novo_usuario) : ''; ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="senha">Senha:</label>
                                <div class="input-group">
                                    <input type="password" name="senha" id="senha" class="form-control" required>
                                    <span class="input-group-text toggle-password-span" style="cursor: pointer; background-color: #333; border-color: #444;">
                                        <i class="fa-solid fa-eye toggle-password" id="toggle-senha"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nivel">Nível de Acesso:</label>
                                <select name="nivel" id="nivel" class="form-select" required>
                                    <option value="usuario" <?php echo (!isset($nivel_novo_usuario) || $nivel_novo_usuario === "usuario") ? "selected" : ""; ?>>Usuário</option>
                                    <option value="admin" <?php echo (isset($nivel_novo_usuario) && $nivel_novo_usuario === "admin") ? "selected" : ""; ?>>Administrador</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-4">
                        <a href="painel.php" class="btn btn-secondary btn-cancel">Cancelar</a>
                        <button type="submit" class="btn btn-primary btn-submit">Cadastrar Usuário</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>

<!-- Scripts específicos da página -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Preview do Avatar
    const avatarInput = document.getElementById("avatar");
    const avatarPreviewImg = document.getElementById("avatar-preview-img");
    const avatarIcon = document.getElementById("avatar-icon");

    if (avatarInput && avatarPreviewImg && avatarIcon) {
        avatarInput.addEventListener("change", function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    avatarPreviewImg.src = e.target.result;
                    avatarPreviewImg.style.display = "block";
                    avatarIcon.style.display = "none";
                }
                reader.readAsDataURL(file);
            } else {
                avatarPreviewImg.src = "#";
                avatarPreviewImg.style.display = "none";
                avatarIcon.style.display = "block";
            }
        });
    }

    // Toggle Visibilidade da Senha
    const togglePassword = document.getElementById("toggle-senha");
    const passwordInput = document.getElementById("senha");
    const togglePasswordSpan = document.querySelector(".toggle-password-span");

    if (togglePassword && passwordInput && togglePasswordSpan) {
        togglePasswordSpan.addEventListener("click", function() {
            // Alterna o tipo do input
            const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
            passwordInput.setAttribute("type", type);
            
            // Alterna o ícone do olho
            togglePassword.classList.toggle("fa-eye");
            togglePassword.classList.toggle("fa-eye-slash");
        });
    }
});
</script>

<?php
// Inclui o rodapé padrão
include("includes/footer.php");
?>

