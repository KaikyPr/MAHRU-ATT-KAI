<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');  // Redireciona para a página de login
    exit;
}

// Conexão com o banco de dados
include('db/conexao.php');

// Verifica se o ID do hack foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$hack_id = (int)$_GET['id'];

// Busca os dados do hack
$sql = "SELECT * FROM hacks WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':id', $hack_id);
$stmt->execute();

$hack = $stmt->fetch(PDO::FETCH_ASSOC);

// Se o hack não existir, redireciona para a página inicial
if (!$hack) {
    header('Location: index.php');
    exit;
}

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION['usuario_id']}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);
$nome_usuario = $usuario['nome'];
$nivel_usuario = $usuario['nivel'];
$avatar_usuario = isset($usuario['avatar']) && !empty($usuario['avatar']) ? $usuario['avatar'] : 'img/avatar-default.png';

// Verifica se o formulário foi enviado
if (isset($_POST['atualizar'])) {
    $nome = htmlspecialchars($_POST['nome']);
    $descricao = htmlspecialchars($_POST['descricao']);
    $piso = (int)$_POST['piso'];
    $tipo = htmlspecialchars($_POST['tipo']);
    
    // Inicializa a variável para armazenar o nome da imagem
    $imagemNome = $hack['imagem']; // Mantém a imagem atual por padrão
    
    // Verifica se uma nova imagem foi enviada
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagemTmp = $_FILES['imagem']['tmp_name'];
        $imagemSize = $_FILES['imagem']['size'];
        $imagemExt = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
        
        // Validar a extensão da imagem
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array(strtolower($imagemExt), $allowedExts)) {
            $errorMessage = "Tipo de imagem não permitido!";
        } else {
            // Definir o nome da nova imagem
            $imagemNovoNome = uniqid('', true) . '.' . $imagemExt;
            $imagemDestino = 'uploads/' . $imagemNovoNome;
            
            // Fazer o upload da nova imagem
            if (move_uploaded_file($imagemTmp, $imagemDestino)) {
                // Se o upload for bem-sucedido, atualiza o nome da imagem
                $imagemNome = $imagemDestino;
                
                // Remove a imagem antiga se não for a padrão
                if ($hack['imagem'] && file_exists($hack['imagem']) && $hack['imagem'] != 'img/hack-default.jpg') {
                    unlink($hack['imagem']);
                }
            } else {
                $errorMessage = "Erro ao fazer upload da nova imagem. Tente novamente.";
            }
        }
    }
    
    if (!isset($errorMessage)) {
        // Atualiza os dados no banco de dados
        $sql = "UPDATE hacks SET nome = :nome, descricao = :descricao, piso = :piso, tipo = :tipo, imagem = :imagem WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':descricao', $descricao);
        $stmt->bindParam(':piso', $piso);
        $stmt->bindParam(':tipo', $tipo);
        $stmt->bindParam(':imagem', $imagemNome);
        $stmt->bindParam(':id', $hack_id);
        
        if ($stmt->execute()) {
            $successMessage = "Hack atualizado com sucesso!";
            
            // Atualiza os dados do hack na variável para exibição
            $hack['nome'] = $nome;
            $hack['descricao'] = $descricao;
            $hack['piso'] = $piso;
            $hack['tipo'] = $tipo;
            $hack['imagem'] = $imagemNome;
            
            // Redireciona após 2 segundos
            header("refresh:2; url=visualizar_hack.php?id=$hack_id");
        } else {
            $errorMessage = "Erro ao atualizar hack. Tente novamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title>Editar Hack - MAHRU</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
</head>
<body>
    <!-- Overlay de carregamento -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <img alt="image" src="<?php echo $avatar_usuario; ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo $nome_usuario; ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            
            <!-- Sidebar -->
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <!-- Removido a duplicidade, mantendo apenas uma instância do nome -->
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li class="active"><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario === 'admin'): ?>
                        <li class="menu-header">Administração</li>
                        <li><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header animate__animated animate__fadeInDown">
                        <h1>Editar Hack</h1>
                        <div class="section-header-breadcrumb">
                            <div class="breadcrumb-item"><a href="painel.php">Visão Geral</a></div>
                            <div class="breadcrumb-item"><a href="index.php">Visualizar Hacks</a></div>
                            <div class="breadcrumb-item"><a href="visualizar_hack.php?id=<?php echo $hack_id; ?>">Detalhes</a></div>
                            <div class="breadcrumb-item active">Editar</div>
                        </div>
                    </div>
                    
                    <div class="section-body">
                        <?php if (isset($successMessage)): ?>
                            <div class="success-message animate__animated animate__fadeIn"><?php echo $successMessage; ?></div>
                        <?php endif; ?>

                        <?php if (isset($errorMessage)): ?>
                            <div class="error-message animate__animated animate__fadeIn"><?php echo $errorMessage; ?></div>
                        <?php endif; ?>
                        
                        <div class="form-container animate__animated animate__fadeInUp">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="current-image-container">
                                        <h4 class="image-title">Imagem Atual</h4>
                                        <div class="image-preview">
                                            <img src="<?php echo htmlspecialchars($hack['imagem']); ?>" alt="<?php echo htmlspecialchars($hack['nome']); ?>" class="img-fluid rounded shadow">
                                        </div>
                                        <p class="image-note">Envie uma nova imagem apenas se desejar substituí-la.</p>
                                    </div>
                                </div>
                                
                                <div class="col-lg-8">
                                    <h2 class="form-title">Editar Informações do Hack</h2>
                                    
                                    <form action="editar_hack.php?id=<?php echo $hack_id; ?>" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="nome">Nome do Hack:</label>
                                                    <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($hack['nome']); ?>" required>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="piso">Piso:</label>
                                                    <select name="piso" id="piso" class="form-select" required>
                                                        <option value="1" <?php echo ($hack['piso'] == 1) ? 'selected' : ''; ?>>Piso 1</option>
                                                        <option value="2" <?php echo ($hack['piso'] == 2) ? 'selected' : ''; ?>>Piso 2</option>
                                                        <option value="3" <?php echo ($hack['piso'] == 3) ? 'selected' : ''; ?>>Piso 3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="descricao">Descrição:</label>
                                            <textarea name="descricao" id="descricao" class="form-control" rows="4" required><?php echo htmlspecialchars($hack['descricao']); ?></textarea>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="tipo">Tipo:</label>
                                                    <select name="tipo" id="tipo" class="form-select" required>
                                                        <option value="interno" <?php echo ($hack['tipo'] == 'interno') ? 'selected' : ''; ?>>Interno</option>
                                                        <option value="externo" <?php echo ($hack['tipo'] == 'externo') ? 'selected' : ''; ?>>Externo</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="imagem">Nova Imagem (opcional):</label>
                                                    <input type="file" name="imagem" id="imagem" class="form-control" accept="image/*">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="new-image-preview-container text-center mb-4" style="display: none;">
                                            <h4 class="mb-3">Pré-visualização da Nova Imagem</h4>
                                            <div class="image-preview">
                                                <img id="preview-img" src="#" alt="Preview" style="max-width: 100%; max-height: 300px; border-radius: 10px;">
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between mt-4">
                                            <a href="visualizar_hack.php?id=<?php echo $hack_id; ?>" class="btn-cancel btn-hover-effect mahru-link">
                                                <i class="fas fa-arrow-left me-2"></i> Voltar
                                            </a>
                                            <button type="submit" name="atualizar" class="btn-submit btn-hover-effect">
                                                <i class="fas fa-save me-2"></i> Atualizar Hack
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
            <!-- Footer -->
            <footer class="main-footer">
                <div class="footer-left">
                    &copy; 2025 MAHRU - Mapeamento de Hacks de Rede UNESC
                </div>
                <div class="footer-right">
                    v2.0
                </div>
            </footer>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Garantir que a animação de carregamento seja exibida por pelo menos 1 segundo
        document.addEventListener('DOMContentLoaded', function() {
            // Forçar exibição do loading por pelo menos 1 segundo
            document.getElementById('loading-overlay').style.display = 'flex';
            document.getElementById('app').classList.add('hidden-content');
            
            setTimeout(function() {
                document.getElementById('loading-overlay').classList.add('fade-out');
                document.getElementById('app').classList.remove('hidden-content');
                
                setTimeout(function() {
                    document.getElementById('loading-overlay').style.display = 'none';
                }, 500);
            }, 1000); // Forçar 1 segundo de carregamento
        });
        
        // Interceptar todos os cliques em links para mostrar animação de carregamento
        document.addEventListener('click', function(e) {
            // Verificar se o clique foi em um link interno
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                const link = e.target.tagName === 'A' ? e.target : e.target.closest('a');
                
                // Verificar se é um link interno (não é # e está no mesmo domínio)
                if (link.getAttribute('href') && 
                    link.getAttribute('href') !== '#' && 
                    link.hostname === window.location.hostname &&
                    !link.classList.contains('dropdown-toggle') && // Ignorar toggles de dropdown
                    !link.hasAttribute('data-toggle') && // Ignorar toggles de sidebar
                    !link.hasAttribute('data-bs-toggle')) { // Ignorar toggles de modal
                    
                    e.preventDefault();
                    
                    // Mostrar overlay de carregamento
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const app = document.getElementById('app');
                    
                    loadingOverlay.classList.remove('fade-out');
                    loadingOverlay.style.display = 'flex';
                    app.classList.add('hidden-content');
                    
                    // Redirecionar após 1 segundo
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 1000);
                }
            }
        });
        
        // Toggle sidebar
        document.querySelector('[data-toggle="sidebar"]').addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector('body').classList.toggle('sidebar-gone');
        });
        
        // Preview de imagem
        document.getElementById('imagem').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview-img').src = e.target.result;
                    document.querySelector('.new-image-preview-container').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
        
        // Efeito de hover nos inputs
        const inputs = document.querySelectorAll('.form-control, .form-select');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('input-focus');
            });
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('input-focus');
            });
        });
    </script>
</body>
</html>
