<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit;
}

// Conexão com o banco de dados
include("db/conexao.php");

// Obter informações do usuário
$query = $pdo->query("SELECT * FROM usuarios WHERE id = '{$_SESSION["usuario_id"]}'");
$usuario = $query->fetch(PDO::FETCH_ASSOC);

// Adiciona verificação para garantir que o usuário foi encontrado
if (!$usuario) {
    die("Erro crítico: Não foi possível carregar os dados do usuário logado. Por favor, tente fazer login novamente.");
}

// Define as variáveis ANTES de incluir o header, caso o header as utilize
$nome_usuario = $usuario["nome"];
$email_usuario = $usuario["email"];
$nivel_usuario = $usuario["nivel"];
$avatar_usuario = isset($usuario["avatar"]) && !empty($usuario["avatar"]) ? $usuario["avatar"] : "img/img-sem-foto.jpg";
$_SESSION['nome_usuario'] = $nome_usuario; // Garante que a sessão está atualizada para o header
$_SESSION['avatar_usuario'] = $avatar_usuario;
$_SESSION['usuario_nivel'] = $nivel_usuario; // Garante que o nível está na sessão para o header

// Mensagens de erro/sucesso
$mensagem = "";
$tipo_mensagem = "";

// Processar formulário de atualização
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $senha_atual = $_POST["senha_atual"];
    $nova_senha = $_POST["nova_senha"];
    
    // Verificar se a senha atual está correta usando password_verify
    if (!empty($senha_atual) && isset($usuario["senha"]) && password_verify($senha_atual, $usuario["senha"])) {
        // Senha atual correta, prosseguir com a atualização
        $sql = "UPDATE usuarios SET nome = :nome, email = :email";
        $params = [":nome" => $nome, ":email" => $email];
        
        // Se uma nova senha foi fornecida, hasheá-la e adicioná-la à query
        if (!empty($nova_senha)) {
            if (strlen($nova_senha) < 6) { // Adiciona validação de tamanho mínimo
                 $mensagem = "A nova senha deve ter pelo menos 6 caracteres.";
                 $tipo_mensagem = "error";
                 // Interrompe a execução da atualização se a nova senha for inválida
                 goto end_of_processing; // Pula para o final do bloco if ($_SERVER...)
            }
            $hash_nova_senha = password_hash($nova_senha, PASSWORD_DEFAULT);
            $sql .= ", senha = :senha";
            $params[":senha"] = $hash_nova_senha;
        }
        
        // Processar upload de avatar (se fornecido)
        $caminho_avatar_atualizado = $avatar_usuario;
        if (isset($_FILES["avatar"]) && $_FILES["avatar"]["error"] == 0) {
            $avatar_nome = $_FILES["avatar"]["name"];
            $avatar_tmp = $_FILES["avatar"]["tmp_name"];
            $avatar_ext = strtolower(pathinfo($avatar_nome, PATHINFO_EXTENSION));
            $extensoes_permitidas = ["jpg", "jpeg", "png", "gif"];
            if (in_array($avatar_ext, $extensoes_permitidas)) {
                $diretorio_avatar = "uploads/avatares/";
                if (!is_dir($diretorio_avatar)) {
                    mkdir($diretorio_avatar, 0755, true);
                }
                $novo_nome = uniqid("avatar_") . "." . $avatar_ext;
                $caminho_avatar_atualizado = $diretorio_avatar . $novo_nome;
                if (move_uploaded_file($avatar_tmp, $caminho_avatar_atualizado)) {
                    $sql .= ", avatar = :avatar";
                    $params[":avatar"] = $caminho_avatar_atualizado;
                    // Opcional: Remover avatar antigo se $avatar_usuario não for o padrão
                    if ($avatar_usuario !== "img/img-sem-foto.jpg" && file_exists($avatar_usuario)) {
                        unlink($avatar_usuario);
                    }
                } else {
                     $caminho_avatar_atualizado = $avatar_usuario; // Falha no upload, mantém o antigo
                     $mensagem = "Erro ao fazer upload do novo avatar. As outras informações foram salvas.";
                     $tipo_mensagem = "warning"; // Avisa sobre o avatar, mas continua
                }
            }
        }
        
        $sql .= " WHERE id = :id";
        $params[":id"] = $_SESSION["usuario_id"];
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute($params)) {
            // Atualiza mensagem de sucesso apenas se não houve aviso de avatar
            if ($tipo_mensagem !== "warning") {
                 $mensagem = "Perfil atualizado com sucesso!";
                 $tipo_mensagem = "success";
            }
            // Atualiza variáveis locais e de sessão
            $nome_usuario = $nome;
            $email_usuario = $email;
            $avatar_usuario = $caminho_avatar_atualizado;
            $_SESSION["nome_usuario"] = $nome_usuario;
            $_SESSION["avatar_usuario"] = $avatar_usuario;
        } else {
            $mensagem = "Erro ao atualizar perfil no banco de dados.";
            $tipo_mensagem = "error";
        }
    } elseif (empty($senha_atual)) {
        $mensagem = "Digite sua senha atual para confirmar as alterações.";
        $tipo_mensagem = "error";
    } else {
        // password_verify falhou ou senha não existe no banco
        $mensagem = "Senha atual incorreta.";
        $tipo_mensagem = "error";
    }
    
    end_of_processing: // Label para o goto em caso de erro na validação da nova senha
}
}

// Define o título da página
$page_title = 'Editar Perfil - MAHRU';

// Inclui o cabeçalho padrão
include('includes/header.php');
?>

<!-- Estilos específicos da página (dentro do <head> via header.php ou aqui) -->
<style>
    .profile-container {
        background-color: var(--card-bg);
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        max-width: 900px;
        margin: 20px auto;
        border-top: 3px solid var(--primary-color);
    }
    .profile-title {
        color: var(--primary-color);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #444;
    }
    .avatar-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 30px;
    }
    .avatar-preview {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        overflow: hidden;
        margin-bottom: 15px;
        border: 3px solid var(--primary-color);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        background-color: #333;
    }
    .avatar-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .form-group label[for="senha_atual"] {
        font-weight: bold;
    }
    .user-info {
        background-color: rgba(0,0,0,0.1);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        border: 1px solid #444;
    }
    .user-info p {
        margin-bottom: 8px;
        font-size: 1.1em;
    }
    .user-info strong {
        color: var(--primary-color);
        margin-right: 5px;
    }

    /* Estilo para placeholder dos campos de senha */
    input[type="password"]::placeholder,
    input[type="text"][placeholder="Digite sua senha"]::placeholder { /* Aplicar também quando for texto */
        color: #adb5bd !important; /* Cinza claro */
        font-style: italic !important;
        opacity: 1 !important; /* Garante visibilidade */
    }
    input[type="password"]::-webkit-input-placeholder,
    input[type="text"][placeholder="Digite sua senha"]::-webkit-input-placeholder {
        color: #adb5bd !important;
        font-style: italic !important;
    }
    input[type="password"]::-moz-placeholder,
    input[type="text"][placeholder="Digite sua senha"]::-moz-placeholder {
        color: #adb5bd !important;
        font-style: italic !important;
        opacity: 1 !important;
    }
    input[type="password"]:-ms-input-placeholder,
    input[type="text"][placeholder="Digite sua senha"]:-ms-input-placeholder {
        color: #adb5bd !important;
        font-style: italic !important;
    }
    input[type="password"]::-ms-input-placeholder,
    input[type="text"][placeholder="Digite sua senha"]::-ms-input-placeholder {
        color: #adb5bd !important;
        font-style: italic !important;
    }

    /* Ajuste no input-group para o ícone */
    .input-group-text.toggle-password-span {
        background-color: #333;
        border-color: #444;
        cursor: pointer;
    }
    .toggle-password {
        color: #999;
    }
    .toggle-password:hover {
        color: var(--primary-color);
    }
</style>

<!-- Conteúdo Principal da Página -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Editar Perfil</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="painel.php">Visão Geral</a></div>
                <div class="breadcrumb-item">Editar Perfil</div>
            </div>
        </div>
        
        <div class="section-body">
            <div class="profile-container">
                <h2 class="profile-title">Informações do Perfil</h2>
                
                <?php if (!empty($mensagem)): ?>
                    <div class="alert <?php echo $tipo_mensagem === "success" ? "alert-success" : "alert-danger"; ?> animate__animated animate__fadeIn">
                        <?php echo htmlspecialchars($mensagem); ?>
                    </div>
                <?php endif; ?>
                
                <div class="user-info">
                    <p><strong>Nome Atual:</strong> <?php echo htmlspecialchars($nome_usuario); ?></p>
                    <p><strong>Email Atual:</strong> <?php echo htmlspecialchars($email_usuario); ?></p>
                    <p><strong>Nível de Acesso:</strong> <?php echo ucfirst(htmlspecialchars($nivel_usuario)); ?></p>
                </div>
                
                <form action="editar-perfil.php" method="POST" enctype="multipart/form-data">
                    <div class="avatar-container">
                        <div class="avatar-preview">
                            <img src="<?php echo htmlspecialchars($avatar_usuario); ?>" alt="Avatar" id="avatar-preview-img">
                        </div>
                        <div class="form-group">
                            <label for="avatar">Alterar Avatar (Opcional):</label>
                            <input type="file" name="avatar" id="avatar" class="form-control" accept="image/*">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nome">Nome:</label>
                                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($nome_usuario); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($email_usuario); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                         <div class="col-md-6">
                            <div class="form-group">
                                <label for="nova_senha">Nova Senha (deixe em branco para não alterar):</label>
                                <div class="input-group">
                                    <input type="password" name="nova_senha" id="nova_senha" class="form-control" placeholder="Digite sua senha">
                                    <span class="input-group-text toggle-password-span">
                                        <i class="fa-solid fa-eye toggle-password" data-target="nova_senha"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="senha_atual">Senha Atual (obrigatória para salvar):</label>
                                <div class="input-group">
                                    <input type="password" name="senha_atual" id="senha_atual" class="form-control" placeholder="Digite sua senha" required>
                                    <span class="input-group-text toggle-password-span">
                                        <i class="fa-solid fa-eye toggle-password" data-target="senha_atual"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-4">
                        <a href="painel.php" class="btn btn-secondary btn-cancel">Cancelar</a>
                        <button type="submit" class="btn btn-primary btn-submit">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>

<!-- Scripts específicos da página (colocados antes do footer) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Preview do Avatar
    const avatarInput = document.getElementById('avatar');
    const avatarPreviewImg = document.getElementById('avatar-preview-img');
    if (avatarInput && avatarPreviewImg) {
        avatarInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    avatarPreviewImg.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Toggle Visibilidade da Senha
    const togglePasswordSpans = document.querySelectorAll(".toggle-password-span");
    togglePasswordSpans.forEach(span => {
        span.addEventListener("click", function() {
            const icon = this.querySelector('i');
            const targetInputId = icon.getAttribute("data-target");
            const passwordInput = document.getElementById(targetInputId);

            if (passwordInput) {
                const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
                passwordInput.setAttribute("type", type);
                icon.classList.toggle("fa-eye");
                icon.classList.toggle("fa-eye-slash");
            }
        });
    });
});
</script>

<?php
// Inclui o rodapé padrão
include('includes/footer.php');
?>

